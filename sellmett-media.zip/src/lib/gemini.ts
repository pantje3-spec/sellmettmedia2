import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function generateReview(businessName: string, rating: number, keywords: string = "") {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Write a short, natural-sounding customer review for a business named "${businessName}". 
      The rating given is ${rating} stars. 
      ${keywords ? `Include these points: ${keywords}.` : ""}
      Write it in "Hinglish" (Hindi written in English script) to make it sound like a real local customer.
      Keep it under 30 words.`,
      config: {
        temperature: 0.8,
        topP: 0.95,
      },
    });

    return response.text || "";
  } catch (error) {
    console.error("Error generating review:", error);
    return "";
  }
}
