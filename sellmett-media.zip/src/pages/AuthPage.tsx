import { useState } from 'react';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { auth, db } from '@/firebase';
import { doc, getDoc, setDoc, serverTimestamp, Timestamp } from 'firebase/firestore';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { QrCode, LogIn } from 'lucide-react';
import { toast } from 'sonner';

export default function AuthPage() {
  const [loading, setLoading] = useState(false);

  const handleGoogleLogin = async () => {
    setLoading(true);
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;

      // Check if user exists in Firestore
      const userRef = doc(db, 'users', user.uid);
      const userSnap = await getDoc(userRef);

      if (!userSnap.exists()) {
        // Create user profile
        const isSuperAdmin = user.email === 'pantje3@gmail.com';
        const trialDays = 7;
        const trialEndsAt = new Date();
        trialEndsAt.setDate(trialEndsAt.getDate() + trialDays);

        await setDoc(userRef, {
          id: user.uid,
          email: user.email,
          displayName: user.displayName || '',
          phoneNumber: '', // Will be updated in settings
          role: isSuperAdmin ? 'super_admin' : 'owner',
          plan: 'free',
          trialEndsAt: Timestamp.fromDate(trialEndsAt),
          createdAt: serverTimestamp(),
        });
        toast.success('Welcome to SellMett Media! Your 7-day free trial has started.');
      } else {
        toast.success('Welcome back!');
      }
    } catch (error) {
      console.error('Auth error:', error);
      toast.error('Failed to sign in. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-zinc-50 px-6">
      <Card className="w-full max-w-md border-zinc-200 shadow-xl rounded-3xl overflow-hidden">
        <div className="h-2 bg-orange-500 w-full" />
        <CardHeader className="text-center pt-10 pb-6">
          <div className="flex justify-center mb-4">
            <div className="w-12 h-12 bg-orange-500 rounded-2xl flex items-center justify-center shadow-lg shadow-orange-200">
              <QrCode className="text-white w-7 h-7" />
            </div>
          </div>
          <CardTitle className="text-3xl font-bold tracking-tight">SellMett Media</CardTitle>
          <CardDescription className="text-zinc-500 text-lg mt-2">
            Grow your business with smart reviews.
          </CardDescription>
        </CardHeader>
        <CardContent className="pb-12 px-10">
          <div className="space-y-6">
            <Button 
              onClick={handleGoogleLogin} 
              disabled={loading}
              className="w-full h-14 bg-white hover:bg-zinc-50 text-zinc-900 border-2 border-zinc-200 rounded-full font-bold text-lg flex items-center justify-center gap-3 transition-all"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-zinc-300 border-t-zinc-900 rounded-full animate-spin" />
              ) : (
                <>
                  <img src="https://www.google.com/favicon.ico" className="w-5 h-5" alt="Google" />
                  Continue with Google
                </>
              )}
            </Button>
            
            <p className="text-center text-zinc-400 text-sm">
              By continuing, you agree to our <a href="#" className="underline">Terms of Service</a> and <a href="#" className="underline">Privacy Policy</a>.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
