import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { db } from '@/firebase';
import { doc, getDoc, addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { Star, Wand2, CheckCircle2, QrCode } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { generateReview } from '@/lib/gemini';
import { motion, AnimatePresence } from 'motion/react';

export default function ReviewPage() {
  const { businessId } = useParams();
  const [business, setBusiness] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [comment, setComment] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    async function fetchBusiness() {
      if (!businessId) return;
      try {
        const docRef = doc(db, 'businesses', businessId);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setBusiness({
            ...data,
            settings: data.settings || { showName: true, showPhone: true }
          });
        }
      } catch (error) {
        console.error('Error fetching business:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchBusiness();
  }, [businessId]);

  const handleGenerateAI = async () => {
    if (rating === 0) {
      toast.error('Pehle rating select karein! (Please select a rating first)');
      return;
    }
    setIsGenerating(true);
    const aiReview = await generateReview(business.name, rating);
    setComment(aiReview);
    setIsGenerating(false);
    toast.success('AI ne aapke liye review likh diya hai! ✨');
  };

  const handleSubmit = async () => {
    if (rating === 0) {
      toast.error('Please select a rating');
      return;
    }
    try {
      await addDoc(collection(db, 'reviews'), {
        id: Math.random().toString(36).substr(2, 9),
        businessId,
        rating,
        comment,
        customerName: business.settings.showName ? customerName : '',
        customerPhone: business.settings.showPhone ? customerPhone : '',
        aiGenerated: comment.length > 0 && !isGenerating, // Simple heuristic
        createdAt: serverTimestamp(),
      });
      setSubmitted(true);
      
      // If business has a google review URL, redirect after a delay
      if (business.googleReviewUrl) {
        setTimeout(() => {
          window.location.href = business.googleReviewUrl;
        }, 2000);
      }
    } catch (error) {
      console.error('Error submitting review:', error);
      toast.error('Failed to submit review. Please try again.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-50">
        <div className="w-10 h-10 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!business) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-50 px-6 text-center">
        <div>
          <h1 className="text-2xl font-bold mb-2">Business Not Found</h1>
          <p className="text-zinc-500">The QR code might be invalid or the business is no longer registered.</p>
        </div>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-50 px-6">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full text-center"
        >
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-10 h-10 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold mb-4">Thank You!</h1>
          <p className="text-zinc-600 mb-8 text-lg">
            Aapka review submit ho gaya hai. {business.googleReviewUrl && "Ab aapko Google Maps par redirect kiya ja raha hai..."}
          </p>
          {business.googleReviewUrl && (
            <Button 
              onClick={() => window.location.href = business.googleReviewUrl}
              className="bg-orange-500 hover:bg-orange-600 text-white rounded-full px-8 h-12 font-bold"
            >
              Go to Google Review
            </Button>
          )}
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-50 py-12 px-6">
      <div className="max-w-md mx-auto">
        <div className="flex items-center justify-center gap-2 mb-8">
          <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
            <QrCode className="text-white w-4 h-4" />
          </div>
          <span className="font-bold text-lg tracking-tight">SellMett Media</span>
        </div>

        <Card className="border-zinc-200 shadow-xl rounded-3xl overflow-hidden">
          <div className="h-2 bg-orange-500 w-full" />
          <CardHeader className="text-center pt-8">
            <CardTitle className="text-2xl font-bold">{business.name}</CardTitle>
            <CardDescription>{business.address || "Share your experience with us"}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-8 pb-10">
            {/* Star Rating */}
            <div className="flex flex-col items-center gap-4">
              <p className="font-semibold text-zinc-700">Aapko hamari service kaisi lagi?</p>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    onMouseEnter={() => setHover(star)}
                    onMouseLeave={() => setHover(0)}
                    className="transition-transform active:scale-90"
                  >
                    <Star 
                      className={`w-10 h-10 ${
                        (hover || rating) >= star 
                          ? "fill-orange-400 text-orange-400" 
                          : "text-zinc-300"
                      } transition-colors`} 
                    />
                  </button>
                ))}
              </div>
              {rating > 0 && (
                <motion.p 
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-orange-600 font-bold"
                >
                  {rating === 5 ? "Excellent! 😍" : rating === 4 ? "Very Good! 😊" : rating === 3 ? "Good! 🙂" : rating === 2 ? "Bad! ☹️" : "Very Bad! 😡"}
                </motion.p>
              )}
            </div>

            {/* Review Text */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-sm font-bold text-zinc-700">Aapka Review (Optional)</label>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={handleGenerateAI}
                  disabled={isGenerating || rating === 0}
                  className="text-orange-600 hover:text-orange-700 hover:bg-orange-50 font-bold gap-2 h-8"
                >
                  {isGenerating ? (
                    <div className="w-4 h-4 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Wand2 className="w-4 h-4" />
                  )}
                  AI se likhwayein
                </Button>
              </div>
              <Textarea 
                placeholder="Apna anubhav share karein..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                className="min-h-[120px] rounded-2xl border-zinc-200 focus:ring-orange-500 focus:border-orange-500"
              />
            </div>

            {/* Customer Name */}
            {business.settings.showName && (
              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-700">Aapka Naam (Optional)</label>
                <Input 
                  placeholder="Enter your name"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="rounded-xl border-zinc-200"
                />
              </div>
            )}

            {/* Customer Phone */}
            {business.settings.showPhone && (
              <div className="space-y-2">
                <label className="text-sm font-bold text-zinc-700">Aapka Number (Optional)</label>
                <Input 
                  placeholder="Enter your phone number"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="rounded-xl border-zinc-200"
                />
              </div>
            )}

            <Button 
              onClick={handleSubmit}
              disabled={rating === 0}
              className="w-full h-14 bg-orange-500 hover:bg-orange-600 text-white rounded-full font-bold text-lg shadow-lg shadow-orange-100 transition-all"
            >
              Submit Review
            </Button>
          </CardContent>
        </Card>
        
        <p className="text-center mt-8 text-zinc-400 text-xs">
          Powered by SellMett Media • Smart QR Reviews
        </p>
      </div>
    </div>
  );
}
