import { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import { auth, db } from '@/firebase';
import { collection, query, where, onSnapshot, doc, getDoc, setDoc, deleteDoc, serverTimestamp } from 'firebase/firestore';
import { 
  LayoutDashboard, 
  Store, 
  Star, 
  Settings, 
  LogOut, 
  Plus, 
  QrCode, 
  ExternalLink, 
  Trash2, 
  ChevronRight,
  TrendingUp,
  Users,
  MessageSquare,
  Download,
  AlertCircle,
  Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { QRCodeSVG } from 'qrcode.react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';

export default function Dashboard() {
  const location = useLocation();
  const navigate = useNavigate();
  const [businesses, setBusinesses] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [currentUserData, setCurrentUserData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!auth.currentUser) return;

    // Fetch current user data
    const unsubUser = onSnapshot(doc(db, 'users', auth.currentUser.uid), (doc) => {
      setCurrentUserData(doc.data());
    });

    // Listen to businesses
    let qB;
    if (currentUserData?.role === 'super_admin') {
      qB = query(collection(db, 'businesses'));
    } else {
      qB = query(collection(db, 'businesses'), where('ownerId', '==', auth.currentUser.uid));
    }
    
    const unsubB = onSnapshot(qB, (snap) => {
      const bData = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setBusinesses(bData);
      setLoading(false);
    });

    // Listen to reviews
    const qR = query(collection(db, 'reviews'));
    const unsubR = onSnapshot(qR, (snap) => {
      const rData = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setReviews(rData);
    });

    // Listen to users (only for super_admin)
    let unsubUsers = () => {};
    if (currentUserData?.role === 'super_admin') {
      const qU = query(collection(db, 'users'));
      unsubUsers = onSnapshot(qU, (snap) => {
        const uData = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setUsers(uData);
      });
    }

    return () => {
      unsubUser();
      unsubB();
      unsubR();
      unsubUsers();
    };
  }, [currentUserData?.role]);

  const handleLogout = () => {
    auth.signOut();
    navigate('/');
  };

  const menuItems = [
    { icon: <LayoutDashboard className="w-5 h-5" />, label: 'Overview', path: '/dashboard' },
    { icon: <Store className="w-5 h-5" />, label: 'My Businesses', path: '/dashboard/businesses' },
    { icon: <Star className="w-5 h-5" />, label: 'Reviews', path: '/dashboard/reviews' },
    ...(currentUserData?.role === 'super_admin' ? [{ icon: <Users className="w-5 h-5" />, label: 'Users', path: '/dashboard/users' }] : []),
    { icon: <Settings className="w-5 h-5" />, label: 'Settings', path: '/dashboard/settings' },
  ];

  return (
    <div className="flex min-h-screen bg-zinc-50">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-zinc-200 flex flex-col sticky top-0 h-screen">
        <div className="p-6 flex items-center gap-2 border-b border-zinc-100">
          <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
            <QrCode className="text-white w-5 h-5" />
          </div>
          <span className="font-bold text-xl tracking-tight">SellMett</span>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {menuItems.map((item) => (
            <Link 
              key={item.path} 
              to={item.path}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${
                location.pathname === item.path 
                  ? 'bg-orange-50 text-orange-600' 
                  : 'text-zinc-500 hover:bg-zinc-50 hover:text-zinc-900'
              }`}
            >
              {item.icon}
              {item.label}
            </Link>
          ))}
        </nav>

        {currentUserData?.plan === 'free' && (
          <div className="p-4 mx-4 mb-4 bg-orange-50 rounded-2xl border border-orange-100">
            <div className="flex items-center gap-2 text-orange-600 mb-1">
              <Clock className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider">Free Trial</span>
            </div>
            <p className="text-[10px] text-zinc-500 leading-tight">
              Upgrade to Silver or Gold for unlimited features.
            </p>
          </div>
        )}

        <div className="p-4 border-t border-zinc-100">
          <div className="flex items-center gap-3 px-4 py-3 mb-4">
            <Avatar className="w-10 h-10 border border-zinc-200">
              <AvatarImage src={auth.currentUser?.photoURL || ''} />
              <AvatarFallback>{auth.currentUser?.email?.charAt(0).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold truncate">{currentUserData?.displayName || auth.currentUser?.displayName || 'Business Owner'}</p>
              <p className="text-xs text-zinc-500 truncate">{auth.currentUser?.email}</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            onClick={handleLogout}
            className="w-full justify-start gap-3 text-zinc-500 hover:text-red-600 hover:bg-red-50 rounded-xl"
          >
            <LogOut className="w-5 h-5" />
            Logout
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 overflow-y-auto">
        {currentUserData?.plan === 'free' && (
          <TrialBanner trialEndsAt={currentUserData.trialEndsAt} />
        )}
        <Routes>
          <Route path="/" element={<Overview businesses={businesses} reviews={reviews} role={currentUserData?.role} />} />
          <Route path="/businesses" element={<BusinessManager businesses={businesses} role={currentUserData?.role} />} />
          <Route path="/reviews" element={<ReviewsList reviews={reviews} businesses={businesses} role={currentUserData?.role} />} />
          <Route path="/users" element={<UsersList users={users} />} />
          <Route path="/settings" element={<SettingsPage userData={currentUserData} />} />
        </Routes>
      </main>
    </div>
  );
}

function TrialBanner({ trialEndsAt }: { trialEndsAt: any }) {
  const [daysLeft, setDaysLeft] = useState<number | null>(null);
  const [isExpired, setIsExpired] = useState(false);

  useEffect(() => {
    if (!trialEndsAt) return;
    const end = trialEndsAt.toDate();
    const now = new Date();
    const diff = end.getTime() - now.getTime();
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    setDaysLeft(days);
    setIsExpired(days <= 0);
  }, [trialEndsAt]);

  if (daysLeft === null) return null;

  return (
    <div className={`mb-8 p-4 rounded-3xl flex items-center justify-between gap-4 ${
      isExpired ? 'bg-red-50 border border-red-100' : 'bg-orange-50 border border-orange-100'
    }`}>
      <div className="flex items-center gap-4">
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
          isExpired ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600'
        }`}>
          {isExpired ? <AlertCircle className="w-6 h-6" /> : <Clock className="w-6 h-6" />}
        </div>
        <div>
          <h3 className={`font-bold ${isExpired ? 'text-red-900' : 'text-orange-900'}`}>
            {isExpired ? 'Trial Expired' : `Free Trial: ${daysLeft} days left`}
          </h3>
          <p className="text-sm text-zinc-500">
            {isExpired 
              ? 'Your 7-day free trial has ended. Please upgrade to continue using all features.' 
              : 'You are currently on a 7-day free trial. Upgrade to a paid plan for more benefits.'}
          </p>
        </div>
      </div>
      <Button 
        className={`${isExpired ? 'bg-red-600 hover:bg-red-700' : 'bg-orange-500 hover:bg-orange-600'} text-white rounded-full px-6`}
        onClick={() => {
          const message = encodeURIComponent("Hello SellMett Media, I want to upgrade my plan.");
          window.open(`https://wa.me/91XXXXXXXXXX?text=${message}`, '_blank');
        }}
      >
        Upgrade Now
      </Button>
    </div>
  );
}

function Overview({ businesses, reviews, role }: { businesses: any[], reviews: any[], role?: string }) {
  const avgRating = reviews.length > 0 
    ? (reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length).toFixed(1)
    : '0.0';

  const chartData = [
    { name: 'Mon', reviews: 4 },
    { name: 'Tue', reviews: 7 },
    { name: 'Wed', reviews: 5 },
    { name: 'Thu', reviews: 12 },
    { name: 'Fri', reviews: 18 },
    { name: 'Sat', reviews: 25 },
    { name: 'Sun', reviews: 15 },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">
          {role === 'super_admin' ? 'Super Admin Dashboard' : 'Business Dashboard'}
        </h1>
        <p className="text-zinc-500">
          {role === 'super_admin' ? 'Manage all users and businesses.' : 'Welcome back! Here\'s how your businesses are performing.'}
        </p>
      </div>

      <div className="grid md:grid-cols-4 gap-6">
        <StatCard icon={<Store className="text-blue-600" />} label="Total Businesses" value={businesses.length} color="bg-blue-50" />
        <StatCard icon={<MessageSquare className="text-orange-600" />} label="Total Reviews" value={reviews.length} color="bg-orange-50" />
        <StatCard icon={<Star className="text-yellow-600" />} label="Avg. Rating" value={avgRating} color="bg-yellow-50" />
        <StatCard icon={<TrendingUp className="text-green-600" />} label="Growth" value="+12%" color="bg-green-50" />
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <Card className="rounded-3xl border-zinc-200 shadow-sm">
          <CardHeader>
            <CardTitle>Review Trends</CardTitle>
            <CardDescription>Daily review counts for the last 7 days</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#71717a', fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#71717a', fontSize: 12 }} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  cursor={{ fill: '#f4f4f5' }}
                />
                <Bar dataKey="reviews" fill="#f97316" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="rounded-3xl border-zinc-200 shadow-sm">
          <CardHeader>
            <CardTitle>Recent Reviews</CardTitle>
            <CardDescription>Latest feedback from your customers</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {reviews.slice(0, 5).map((review) => (
                <div key={review.id} className="flex items-start gap-4 p-3 rounded-2xl hover:bg-zinc-50 transition-colors">
                  <div className="w-10 h-10 bg-zinc-100 rounded-full flex items-center justify-center font-bold text-zinc-500">
                    {review.customerName?.charAt(0) || 'C'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="font-bold text-sm truncate">{review.customerName || 'Anonymous Customer'}</p>
                      <div className="flex gap-0.5">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className={`w-3 h-3 ${i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-zinc-200'}`} />
                        ))}
                      </div>
                    </div>
                    <p className="text-xs text-zinc-500 line-clamp-2 italic">"{review.comment}"</p>
                  </div>
                </div>
              ))}
              {reviews.length === 0 && <p className="text-center text-zinc-400 py-8">No reviews yet.</p>}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, color }: any) {
  return (
    <Card className="rounded-3xl border-zinc-200 shadow-sm overflow-hidden">
      <CardContent className="p-6 flex items-center gap-4">
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${color}`}>
          {icon}
        </div>
        <div>
          <p className="text-sm font-medium text-zinc-500">{label}</p>
          <p className="text-2xl font-bold">{value}</p>
        </div>
      </CardContent>
    </Card>
  );
}

function BusinessManager({ businesses, role }: { businesses: any[], role?: string }) {
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newBusiness, setNewBusiness] = useState({ name: '', address: '', googleReviewUrl: '', ownerId: '' });
  const [isSaving, setIsSaving] = useState(false);

  const handleAddBusiness = async () => {
    if (!newBusiness.name || !newBusiness.ownerId) {
      toast.error('Business name and Owner ID are required.');
      return;
    }
    setIsSaving(true);
    try {
      const bId = Math.random().toString(36).substr(2, 9);
      await setDoc(doc(db, 'businesses', bId), {
        id: bId,
        name: newBusiness.name,
        address: newBusiness.address,
        googleReviewUrl: newBusiness.googleReviewUrl,
        ownerId: newBusiness.ownerId,
        settings: { showName: true, showPhone: true },
        createdAt: serverTimestamp(),
      });
      setIsAddOpen(false);
      setNewBusiness({ name: '', address: '', googleReviewUrl: '', ownerId: '' });
      toast.success('Business added successfully!');
    } catch (error) {
      toast.error('Failed to add business.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'businesses', id));
      toast.success('Business deleted.');
    } catch (error) {
      toast.error('Failed to delete business.');
    }
  };

  const handleRequestBusiness = () => {
    const message = encodeURIComponent("Hello SellMett Media, I want to add a new business to my dashboard.");
    window.open(`https://wa.me/91XXXXXXXXXX?text=${message}`, '_blank');
  };

  const toggleSetting = async (biz: any, setting: string) => {
    try {
      const newSettings = {
        ...biz.settings,
        [setting]: !biz.settings[setting]
      };
      await setDoc(doc(db, 'businesses', biz.id), { settings: newSettings }, { merge: true });
      toast.success('Settings updated!');
    } catch (error) {
      toast.error('Failed to update settings.');
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">My Businesses</h1>
          <p className="text-zinc-500">Manage your shops and generate QR codes.</p>
        </div>
        {role === 'super_admin' ? (
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger
              render={
                <Button className="bg-orange-500 hover:bg-orange-600 text-white rounded-full gap-2">
                  <Plus className="w-5 h-5" />
                  Add Business (Admin)
                </Button>
              }
            />
            <DialogContent className="rounded-3xl max-w-md">
              <DialogHeader>
                <DialogTitle>Add New Business</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <label className="text-sm font-bold">Business Name</label>
                  <Input 
                    placeholder="e.g. Sharma Sweets" 
                    value={newBusiness.name}
                    onChange={(e) => setNewBusiness({...newBusiness, name: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold">Owner UID</label>
                  <Input 
                    placeholder="Paste user UID here" 
                    value={newBusiness.ownerId}
                    onChange={(e) => setNewBusiness({...newBusiness, ownerId: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold">Address</label>
                  <Input 
                    placeholder="e.g. Sector 17, Chandigarh" 
                    value={newBusiness.address}
                    onChange={(e) => setNewBusiness({...newBusiness, address: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold">Google Review URL</label>
                  <Input 
                    placeholder="Paste your Google Maps review link" 
                    value={newBusiness.googleReviewUrl}
                    onChange={(e) => setNewBusiness({...newBusiness, googleReviewUrl: e.target.value})}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setIsAddOpen(false)}>Cancel</Button>
                <Button 
                  onClick={handleAddBusiness} 
                  disabled={isSaving}
                  className="bg-orange-500 hover:bg-orange-600 text-white"
                >
                  {isSaving ? 'Saving...' : 'Save Business'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        ) : (
          <Button onClick={handleRequestBusiness} className="bg-orange-500 hover:bg-orange-600 text-white rounded-full gap-2">
            <Plus className="w-5 h-5" />
            Request New Business (Paid)
          </Button>
        )}
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {businesses.map((b) => (
          <Card key={b.id} className="rounded-3xl border-zinc-200 shadow-sm overflow-hidden group">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="w-12 h-12 bg-zinc-100 rounded-2xl flex items-center justify-center">
                  <Store className="w-6 h-6 text-zinc-600" />
                </div>
                <div className="flex gap-2">
                  {role === 'super_admin' && (
                    <Button variant="ghost" size="icon" className="text-zinc-400 hover:text-red-500" onClick={() => handleDelete(b.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
              <h3 className="text-xl font-bold mb-1">{b.name}</h3>
              <p className="text-sm text-zinc-500 mb-4 flex items-center gap-1">
                <ChevronRight className="w-3 h-3" /> {b.address || 'No address provided'}
              </p>

              {/* Settings Toggles */}
              <div className="flex gap-2 mb-6">
                <Button 
                  variant={b.settings?.showName ? "default" : "outline"} 
                  size="sm" 
                  className="text-[10px] h-7 rounded-full"
                  onClick={() => toggleSetting(b, 'showName')}
                >
                  {b.settings?.showName ? 'Name ON' : 'Name OFF'}
                </Button>
                <Button 
                  variant={b.settings?.showPhone ? "default" : "outline"} 
                  size="sm" 
                  className="text-[10px] h-7 rounded-full"
                  onClick={() => toggleSetting(b, 'showPhone')}
                >
                  {b.settings?.showPhone ? 'Phone ON' : 'Phone OFF'}
                </Button>
              </div>
              
              <div className="bg-zinc-50 rounded-2xl p-4 flex flex-col items-center gap-4">
                <div className="bg-white p-2 rounded-xl border border-zinc-200">
                  <QRCodeSVG value={`${window.location.origin}/review/${b.id}`} size={120} />
                </div>
                <div className="flex gap-2 w-full">
                  <Button variant="outline" className="flex-1 rounded-xl text-xs gap-1" onClick={() => window.open(`/review/${b.id}`, '_blank')}>
                    <ExternalLink className="w-3 h-3" /> Preview
                  </Button>
                  <Button variant="outline" className="flex-1 rounded-xl text-xs gap-1" onClick={() => {
                    const svg = document.querySelector(`svg`);
                    if (svg) {
                      const svgData = new XMLSerializer().serializeToString(svg);
                      const canvas = document.createElement("canvas");
                      const ctx = canvas.getContext("2d");
                      const img = new Image();
                      img.onload = () => {
                        canvas.width = img.width;
                        canvas.height = img.height;
                        ctx?.drawImage(img, 0, 0);
                        const pngFile = canvas.toDataURL("image/png");
                        const downloadLink = document.createElement("a");
                        downloadLink.download = `QR_${b.name}.png`;
                        downloadLink.href = `${pngFile}`;
                        downloadLink.click();
                      };
                      img.src = "data:image/svg+xml;base64," + btoa(svgData);
                    }
                  }}>
                    <Download className="w-3 h-3" /> Download
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        ))}
        {businesses.length === 0 && (
          <div className="col-span-full py-20 text-center bg-white rounded-3xl border-2 border-dashed border-zinc-200">
            <Store className="w-12 h-12 text-zinc-300 mx-auto mb-4" />
            <h3 className="text-lg font-bold text-zinc-900">No businesses yet</h3>
            <p className="text-zinc-500 mb-6">Request your first business to start collecting reviews.</p>
            {role === 'super_admin' ? (
              <Button onClick={() => setIsAddOpen(true)} className="bg-orange-500 hover:bg-orange-600 text-white rounded-full">
                Add First Shop
              </Button>
            ) : (
              <Button onClick={handleRequestBusiness} className="bg-orange-500 hover:bg-orange-600 text-white rounded-full">
                Request Shop via WhatsApp
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function ReviewsList({ reviews, businesses, role }: { reviews: any[], businesses: any[], role?: string }) {
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  const handleReply = async (reviewId: string) => {
    if (!replyText) return;
    try {
      await setDoc(doc(db, 'reviews', reviewId), { reply: replyText }, { merge: true });
      setReplyingTo(null);
      setReplyText('');
      toast.success('Reply sent!');
    } catch (error) {
      toast.error('Failed to send reply.');
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Customer Reviews</h1>
        <p className="text-zinc-500">Read and manage feedback from all your businesses.</p>
      </div>

      <div className="space-y-4">
        {reviews.map((review) => {
          const biz = businesses.find(b => b.id === review.businessId);
          if (role !== 'super_admin' && biz?.ownerId !== auth.currentUser?.uid) return null;

          return (
            <Card key={review.id} className="rounded-3xl border-zinc-200 shadow-sm overflow-hidden">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10 border border-zinc-200">
                      <AvatarFallback>{review.customerName?.charAt(0) || 'C'}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-bold">{review.customerName || 'Anonymous Customer'}</p>
                      <p className="text-xs text-zinc-500">{biz?.name || 'Unknown Business'}</p>
                      {review.customerPhone && <p className="text-xs text-orange-500 font-medium">{review.customerPhone}</p>}
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex gap-0.5">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`w-5 h-5 ${i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-zinc-200'}`} />
                      ))}
                    </div>
                    <Badge variant="outline" className="rounded-full font-medium text-xs">
                      {review.createdAt?.seconds ? new Date(review.createdAt.seconds * 1000).toLocaleDateString() : 'Just now'}
                    </Badge>
                  </div>
                </div>
                <div className="bg-zinc-50 p-4 rounded-2xl relative mb-4">
                  <p className="text-zinc-700 italic leading-relaxed">"{review.comment}"</p>
                  {review.aiGenerated && (
                    <div className="absolute -top-2 -right-2">
                      <Badge className="bg-orange-500 text-white border-none shadow-sm">AI Generated</Badge>
                    </div>
                  )}
                </div>

                {review.reply ? (
                  <div className="ml-8 p-4 bg-orange-50 rounded-2xl border border-orange-100">
                    <p className="text-xs font-bold text-orange-600 mb-1">Your Reply:</p>
                    <p className="text-sm text-zinc-700">{review.reply}</p>
                  </div>
                ) : (
                  <div className="ml-8">
                    {replyingTo === review.id ? (
                      <div className="space-y-2">
                        <Textarea 
                          placeholder="Write your reply..." 
                          value={replyText}
                          onChange={(e) => setReplyText(e.target.value)}
                          className="rounded-xl border-zinc-200 min-h-[80px]"
                        />
                        <div className="flex gap-2">
                          <Button size="sm" onClick={() => handleReply(review.id)} className="bg-orange-500 text-white rounded-full">Send Reply</Button>
                          <Button size="sm" variant="ghost" onClick={() => setReplyingTo(null)}>Cancel</Button>
                        </div>
                      </div>
                    ) : (
                      <Button variant="ghost" size="sm" onClick={() => setReplyingTo(review.id)} className="text-orange-600 hover:text-orange-700 hover:bg-orange-50 font-bold gap-2">
                        <MessageSquare className="w-4 h-4" /> Reply to Customer
                      </Button>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
        {reviews.length === 0 && (
          <div className="py-20 text-center bg-white rounded-3xl border-2 border-dashed border-zinc-200">
            <MessageSquare className="w-12 h-12 text-zinc-300 mx-auto mb-4" />
            <h3 className="text-lg font-bold text-zinc-900">No reviews yet</h3>
            <p className="text-zinc-500">Share your QR codes with customers to get feedback.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function UsersList({ users }: { users: any[] }) {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">System Users</h1>
        <p className="text-zinc-500">Manage all registered business owners.</p>
      </div>

      <div className="grid gap-4">
        {users.map((u) => (
          <Card key={u.id} className="rounded-3xl border-zinc-200 shadow-sm overflow-hidden">
            <CardContent className="p-6 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Avatar className="w-12 h-12 border border-zinc-200">
                  <AvatarFallback>{u.email?.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-bold text-lg">{u.displayName || 'No Name'}</p>
                  <p className="text-sm text-zinc-500">{u.email}</p>
                  <p className="text-xs text-orange-500 font-bold">UID: {u.id}</p>
                  {u.phoneNumber && <p className="text-xs text-zinc-400">Phone: {u.phoneNumber}</p>}
                </div>
              </div>
              <div className="text-right">
                <Badge className={u.role === 'super_admin' ? 'bg-purple-500' : 'bg-blue-500'}>
                  {u.role}
                </Badge>
                <p className="text-xs text-zinc-400 mt-2">Joined: {u.createdAt?.seconds ? new Date(u.createdAt.seconds * 1000).toLocaleDateString() : 'N/A'}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

function SettingsPage({ userData }: { userData: any }) {
  const [displayName, setDisplayName] = useState(userData?.displayName || '');
  const [phoneNumber, setPhoneNumber] = useState(userData?.phoneNumber || '');
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await setDoc(doc(db, 'users', auth.currentUser!.uid), {
        displayName,
        phoneNumber
      }, { merge: true });
      toast.success('Profile updated!');
    } catch (error) {
      toast.error('Failed to update profile.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-zinc-500">Manage your account and preferences.</p>
      </div>
      <Card className="rounded-3xl border-zinc-200 shadow-sm max-w-2xl">
        <CardHeader>
          <CardTitle>Account Information</CardTitle>
          <CardDescription>Update your profile details.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-bold">Current Plan</label>
            <div className="flex items-center gap-3">
              <Badge className={`px-3 py-1 rounded-full ${
                userData?.plan === 'gold' ? 'bg-yellow-500' : 
                userData?.plan === 'silver' ? 'bg-zinc-400' : 'bg-orange-500'
              }`}>
                {userData?.plan?.toUpperCase() || 'FREE'}
              </Badge>
              {userData?.plan === 'free' && (
                <span className="text-xs text-zinc-500">
                  Trial ends: {userData?.trialEndsAt?.seconds ? new Date(userData.trialEndsAt.seconds * 1000).toLocaleDateString() : 'N/A'}
                </span>
              )}
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-bold">Email Address</label>
            <Input value={auth.currentUser?.email || ''} disabled className="bg-zinc-50" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-bold">Display Name</label>
            <Input 
              value={displayName} 
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Your full name"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-bold">Phone Number</label>
            <Input 
              value={phoneNumber} 
              onChange={(e) => setPhoneNumber(e.target.value)}
              placeholder="Your WhatsApp number"
            />
          </div>
          <Button 
            onClick={handleSave} 
            disabled={isSaving}
            className="bg-zinc-900 text-white rounded-full px-8"
          >
            {isSaving ? 'Saving...' : 'Save Changes'}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
