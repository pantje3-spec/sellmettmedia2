import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { QrCode, Star, TrendingUp, Zap, ShieldCheck, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function LandingPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Navigation */}
      <nav className="flex items-center justify-between px-6 py-4 border-b border-zinc-200 bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
            <QrCode className="text-white w-5 h-5" />
          </div>
          <span className="font-bold text-xl tracking-tight">SellMett Media</span>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="ghost" className="font-medium" render={<Link to="/auth" />}>
            Login
          </Button>
          <Button className="bg-orange-500 hover:bg-orange-600 text-white font-semibold rounded-full px-6" render={<Link to="/auth" />}>
            Get Started
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-20 pb-32 px-6 overflow-hidden bg-white">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-6xl lg:text-8xl font-bold tracking-tighter leading-[0.9] mb-6">
              Scan karo, <br />
              <span className="text-orange-500">Review lo,</span> <br />
              Grow karo 🚀
            </h1>
            <p className="text-xl text-zinc-600 mb-8 max-w-lg leading-relaxed">
              SellMett Media is a smart QR-based review system that helps local businesses collect real customer reviews instantly. Boost your Google ranking and build trust in seconds.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="bg-zinc-900 hover:bg-zinc-800 text-white rounded-full px-8 h-14 text-lg font-semibold shadow-xl shadow-zinc-200" render={<Link to="/auth" />}>
                Register Your Business
              </Button>
              <Button size="lg" variant="outline" className="rounded-full px-8 h-14 text-lg font-semibold border-2">
                Watch Demo
              </Button>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative z-10 bg-zinc-100 rounded-3xl p-8 border border-zinc-200 shadow-2xl">
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-zinc-100 mb-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-zinc-100 rounded-full" />
                  <div>
                    <div className="w-24 h-3 bg-zinc-100 rounded-full mb-2" />
                    <div className="w-16 h-2 bg-zinc-50 rounded-full" />
                  </div>
                </div>
                <div className="flex gap-1 mb-3">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Star key={i} className="w-5 h-5 fill-orange-400 text-orange-400" />
                  ))}
                </div>
                <p className="text-zinc-700 font-medium italic">
                  "Bohot badhiya service hai! Staff bohot friendly hai aur food quality top notch."
                </p>
                <div className="mt-4 flex justify-end">
                  <span className="text-[10px] uppercase tracking-widest font-bold text-orange-500 bg-orange-50 px-2 py-1 rounded">AI Generated</span>
                </div>
              </div>
              <div className="flex justify-center">
                <div className="bg-white p-4 rounded-2xl shadow-lg border-4 border-zinc-900">
                  <QrCode className="w-32 h-32 text-zinc-900" />
                </div>
              </div>
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-orange-100 rounded-full blur-3xl -z-10 opacity-50" />
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-blue-100 rounded-full blur-3xl -z-10 opacity-50" />
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-zinc-50 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold tracking-tight mb-4">Everything you need to grow</h2>
            <p className="text-zinc-600 max-w-2xl mx-auto">Simple tools designed for local businesses to dominate their local search results.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Zap className="w-6 h-6 text-orange-500" />,
                title: "Instant QR System",
                desc: "Unique QR for every shop. Just scan and review in 2 seconds."
              },
              {
                icon: <TrendingUp className="w-6 h-6 text-blue-500" />,
                title: "Google Ranking Boost",
                desc: "Increase genuine Google reviews and climb to the top of search results."
              },
              {
                icon: <ShieldCheck className="w-6 h-6 text-green-500" />,
                title: "AI Review Generator",
                desc: "Customers don't know what to write? Our AI writes perfect Hinglish reviews."
              },
              {
                icon: <BarChart3 className="w-6 h-6 text-purple-500" />,
                title: "Admin Dashboard",
                desc: "Track total reviews, average ratings, and daily growth analytics."
              },
              {
                icon: <Star className="w-6 h-6 text-yellow-500" />,
                title: "Multi-Business Support",
                desc: "Manage multiple outlets or shops from a single dashboard."
              },
              {
                icon: <Zap className="w-6 h-6 text-pink-500" />,
                title: "Mobile Friendly UI",
                desc: "Fast, lightweight, and works perfectly on any smartphone."
              }
            ].map((f, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -5 }}
                className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm hover:shadow-md transition-all"
              >
                <div className="mb-4 bg-zinc-50 w-12 h-12 rounded-xl flex items-center justify-center">
                  {f.icon}
                </div>
                <h3 className="text-xl font-bold mb-2">{f.title}</h3>
                <p className="text-zinc-600 leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-6 bg-zinc-900 text-white overflow-hidden relative">
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <h2 className="text-5xl lg:text-7xl font-bold tracking-tighter mb-8">Ready to grow your business?</h2>
          <p className="text-xl text-zinc-400 mb-12">Join hundreds of local businesses using SellMett Media to build trust.</p>
          <Button size="lg" className="bg-orange-500 hover:bg-orange-600 text-white rounded-full px-12 h-16 text-xl font-bold" render={<Link to="/auth" />}>
            Start Your Free Trial
          </Button>
        </div>
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-orange-500 rounded-full blur-[120px]" />
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-zinc-200 bg-white">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
              <QrCode className="text-white w-4 h-4" />
            </div>
            <span className="font-bold text-lg tracking-tight">SellMett Media</span>
          </div>
          <p className="text-zinc-500 text-sm">© 2024 SellMett Media. All rights reserved.</p>
          <div className="flex gap-6 text-sm font-medium text-zinc-600">
            <a href="#" className="hover:text-orange-500">Privacy</a>
            <a href="#" className="hover:text-orange-500">Terms</a>
            <a href="#" className="hover:text-orange-500">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
