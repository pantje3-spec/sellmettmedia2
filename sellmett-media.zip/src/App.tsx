import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth } from './firebase';
import LandingPage from './pages/LandingPage';
import ReviewPage from './pages/ReviewPage';
import Dashboard from './pages/Dashboard';
import AuthPage from './pages/AuthPage';
import { Toaster } from '@/components/ui/sonner';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-zinc-50">
        <div className="animate-pulse flex flex-col items-center gap-4">
          <div className="w-12 h-12 bg-orange-500 rounded-full" />
          <p className="text-zinc-500 font-medium">Loading SellMett Media...</p>
        </div>
      </div>
    );
  }

  return (
    <Router>
      <div className="min-h-screen bg-zinc-50 font-sans text-zinc-900">
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/auth" element={user ? <Navigate to="/dashboard" /> : <AuthPage />} />
          <Route path="/dashboard/*" element={user ? <Dashboard /> : <Navigate to="/auth" />} />
          <Route path="/review/:businessId" element={<ReviewPage />} />
        </Routes>
        <Toaster position="top-center" />
      </div>
    </Router>
  );
}
